import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import tiffin.DatabaseConnction;


public class custconsole extends JFrame
{   Connection con;
	PreparedStatement pst ;
	JTextField txtb,txtd;
	JTextArea addr;
	JPanel pnl,pnl1;
	JLabel lb,lb1,lb2,lb3,lb4,home;
	JComboBox cmb;
	Border brd;
	JButton btn,btn1,btn2,btn3,btn4;	
	
	custconsole()
	{	
		con=DatabaseConnction.connectdb();

		setTitle("Manage Customers");
		setLayout(null);
		setSize(600,700);
		brd=BorderFactory.createLineBorder(Color.decode("#F44336"),1);
		
		pnl=new JPanel();
		pnl.setLayout(null);
		pnl.setSize(600, 100);
		pnl.setBackground(Color.decode("#F44336"));		
		add(pnl);
		
		lb=new JLabel(" CUSTOMER CONSOLE");
		lb.setFont(new Font("Arial",Font.BOLD,40));
		lb.setSize(600,100);
		lb.setForeground(Color.WHITE);
		lb.setHorizontalAlignment(SwingConstants.CENTER);
		pnl.add(lb);
		
		home=new JLabel();
		home.setBounds(520,110,32,32);
		add(home);
		ImageIcon homefulll=new ImageIcon("home.png");
		ImageIcon homesmalll=resize_img(homefulll,home.getWidth(),home.getHeight());
		home.setIcon(homesmalll);
		home.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				
				// TODO Auto-generated method stub
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				home.setBorder(null);
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				home.setBorder(brd);
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				home.setBackground(Color.decode("#F44336"));
				dispose();
				admhmpg.main(null);
				
			}
		});
		

		
		pnl1=new JPanel();
		pnl1.setLayout(null);
		pnl1.setBounds(100,150, 400, 400);
		pnl1.setBackground(Color.WHITE);
		add(pnl1);
		pnl1.setBorder(brd);
		
		lb1=new JLabel("CUSTOMER ID:");
		lb1.setFont(new Font("Arial",Font.ITALIC|Font.BOLD,15));
		lb1.setBounds(15,10,120,25);
		pnl1.add(lb1);
		
		cmb=new JComboBox();
		cmb.setBounds(155,10, 100,25);
		pnl1.add(cmb);
		//txta.setHorizontalAlignment(SwingConstants.CENTER);
		cmb.setFont(new Font("AR ESSENCE", Font.PLAIN, 15));
		cmb.setEditable(true);
		
		
		lb2=new JLabel("NAME:");
		lb2.setFont(new Font("Arial",Font.ITALIC|Font.BOLD,15));
		lb2.setBounds(15,45,100,25);
		pnl1.add(lb2);
		
		
		txtb=new JTextField();
		txtb.setBounds(155,45,120,25);
		pnl1.add(txtb);
		txtb.setHorizontalAlignment(SwingConstants.CENTER);
		txtb.setFont(new Font("AR ESSENCE", Font.PLAIN, 20));
		txtb.setToolTipText("Please enter some text here");
		txtb.requestFocusInWindow();
		
		lb3=new JLabel("ADDRESS:");
		lb3.setFont(new Font("Arial",Font.ITALIC|Font.BOLD,15));
		lb3.setBounds(15,80,120,25);
		pnl1.add(lb3);
		
		
		
	    addr=new JTextArea("Fill Address Here", 5, 50);
		JScrollPane scroll = new JScrollPane(addr);
		addr.setFont(new Font("Arial",Font.ITALIC|Font.BOLD,15));
		scroll.setBounds(155, 80, 200, 100);
		addr.setBorder(BorderFactory.createLineBorder(Color.black));
		pnl1.add(scroll);
		
		lb4=new JLabel("MOB NO:");
		lb4.setFont(new Font("Arial",Font.ITALIC|Font.BOLD,15));
		lb4.setBounds(15,190,120,25);
		pnl1.add(lb4);
		
		txtd=new JTextField();
		txtd.setBounds(155,190,120,25);
		pnl1.add(txtd);
		txtd.setHorizontalAlignment(SwingConstants.CENTER);
		txtd.setFont(new Font("AR ESSENCE", Font.PLAIN, 20));
		txtd.setToolTipText("Please enter some text here");
		txtd.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) 
			{
				String mobile="^[789]\\d{9}$";

				boolean b=txtd.getText().matches(mobile);
				if(b==false)
				{
				JOptionPane.showMessageDialog(null,"Invalid mob. no.");
				txtd.requestFocusInWindow();
				}
				else
				{
				txtd.setBackground(Color.white);
				}
				
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				txtd.setBackground(Color.gray);
				
			}
		});
		
		btn1=new JButton("Save");
		btn1.setBounds(40,280,90,30);
		//btn1.setIcon(new ImageIcon("save.png"));
		btn1.setBackground(Color.decode("#F44336"));
		pnl1.add(btn1);
		btn1.setForeground(Color.white);
		btn1.setMnemonic(KeyEvent.VK_S);
		btn1.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					
							       
						pst=con.prepareStatement("insert into addcust values(?,?,?,?)");
						pst.setInt(1,Integer.parseInt((cmb.getSelectedItem().toString())));
						pst.setString(2,txtb.getText());
						pst.setString(3,addr.getText());
						pst.setString(4,txtd.getText());
												 
						int ros=pst.executeUpdate();
						if(ros==1)
						JOptionPane.showMessageDialog(null,ros+"record saved");
						else
							JOptionPane.showMessageDialog(null,ros+"record already existed:");
						
						
					  
				}
				catch(SQLException rx)
				{
					rx.printStackTrace();
				}
				try
				{
					pst.close();
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}
		});
		
		btn3=new JButton("Update");
		btn3.setBounds(150,280,90,30);
		btn3.setBackground(Color.decode("#F44336"));
		btn3.setForeground(Color.white);
		//btn3.setIcon(new ImageIcon("update.png"));
		pnl1.add(btn3);
		btn3.setMnemonic(KeyEvent.VK_U);
	    btn3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e)
			{
				try
				{
				
				pst=con.prepareStatement("update addcust set name=?,address=?,mobno=? where customerid=?");
				pst.setInt(4,Integer.parseInt((cmb.getSelectedItem().toString())));
				pst.setString(1,txtb.getText());
				pst.setString(2,addr.getText());
				pst.setString(3,txtd.getText());
							
				
				int res=pst.executeUpdate();
				if(res==1)
				JOptionPane.showMessageDialog(null, res+" records Updated");
				}
				catch (SQLException ex)
				{
				ex.printStackTrace();
				}
				try{
	
				pst.close();
				}
				catch (Exception ev)
				{
				ev.printStackTrace();
				}
				}
				
			
		});
		
		btn2=new JButton("New");
		btn2.setBounds(260,280,90,30);
		btn2.setBackground(Color.decode("#F44336"));
		btn2.setForeground(Color.white);
		//btn4.setIcon(new ImageIcon("new2.png"));
		pnl1.add(btn2);
		btn2.setMnemonic(KeyEvent.VK_N);
		btn2.addActionListener(new ActionListener()
		{
			
			@Override
			public void actionPerformed(ActionEvent ev)
			{
			
					cmb.setSelectedItem("select");
					txtb.setText("");
					addr.setText("");
					txtd.setText("");
					getid();
					
			}
		});
		

		btn=new JButton("Fetch");
		btn.setBounds(270, 10, 70,25);
		btn.setBackground(Color.decode("#F44336"));
		btn.setForeground(Color.white);
		//btn.setIcon(new ImageIcon("fetch.png"));
		pnl1.add(btn);
		btn.setMnemonic(KeyEvent.VK_F);
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e)
			{
				
				try {
									
					Integer.parseInt(String.valueOf(cmb.getSelectedItem()));			
					pst=con.prepareStatement("SELECT * from addcust where customerid=?");
					pst.setInt(1,Integer.parseInt(String.valueOf(cmb.getSelectedItem())));
					
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						cmb.setSelectedItem(rs.getString(1));
						txtb.setText(rs.getString(2));
						addr.setText(rs.getString(3));
						txtd.setText(rs.getString(4));
						
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		btn4=new JButton("Delete");
		btn4.setBounds(150,330,90,30);
		btn4.setBackground(Color.decode("#F44336"));
		btn4.setForeground(Color.white);
		//btn.setIcon(new ImageIcon("fetch.png"));
		pnl1.add(btn4);
		btn4.setMnemonic(KeyEvent.VK_D);

		btn4.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent ev)
			{  
			  try
				{
					int it=JOptionPane.showConfirmDialog(null,"sure?");
					if(it==0)
					{
						pst=con.prepareStatement("delete from addcust where customerid=?");
						pst.setInt(1,Integer.parseInt((String)cmb.getSelectedItem()));
						int res=pst.executeUpdate();
						JOptionPane.showMessageDialog(null,res+"records deleted");
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
				try
				{
					pst.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			} 
		});


		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getRootPane().setWindowDecorationStyle(JRootPane.ERROR_DIALOG);
		getContentPane().setBackground(Color.WHITE);
		setLocationRelativeTo(null);
		setUndecorated(true);
		setResizable(false);
		setVisible(true);
        getid();
	}
	void getid()
	{
		int aid=1;
		boolean b=false;
		try
		{
			pst=con.prepareStatement("select max(customerid) as 'max' from addcust");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				b=true;
				aid=rs.getInt("max");
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(b==true)
		{
			aid=aid+1;
		}
		
		cmb.setSelectedItem(aid);
	}
	
	ImageIcon resize_img(ImageIcon log,int width,int height)
	{
	Image img=log.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
	ImageIcon bhai=new ImageIcon(img);
	return(bhai);
	}

	
	public static void main(String args[])
	{
		new custconsole();
	}
		
}